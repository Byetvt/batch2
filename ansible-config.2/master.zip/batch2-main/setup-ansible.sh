#!/bin/bash

#source $HOME/setup-ansible.sh

# Define the target path
TARGET_DIR="$HOME/ansible-config"
TARGET_DIR2="$HOME/ansible-config/wineapps"

# 1. Create the config directory if it doesn't exist
if [ ! -d "$TARGET_DIR" ]; then
    echo "Directory $TARGET_DIR does not exist. Creating it now..."
    mkdir -p "$TARGET_DIR"
    echo "Success: Directory created."
else
    echo "Directory $TARGET_DIR already exists. No action needed."
fi

# 2. Check if Ansible is installed
if ! command -v ansible &> /dev/null; then
    echo "Ansible is not installed. Starting installation..."

    # Update package list and install prerequisites
    sudo apt update
    sudo apt install -y software-properties-common

    # Add the official Ansible PPA
    sudo add-apt-repository --yes --update ppa:ansible/ansible

    # Install Ansible
    sudo apt install -y ansible

    echo "Ansible installation complete."
else
    echo "Ansible is already installed: $(ansible --version | head -n 1)"
fi

# 3. Change directory to the config folder
cd "$TARGET_DIR" || exit
echo "Current directory: $(pwd)"


# 3B. Create the wineapps subdirectory if it doesn't exist
if [ ! -d "$TARGET_DIR2" ]; then
    echo "Directory $TARGET_DIR2 does not exist. Creating it now..."
    mkdir -p "$TARGET_DIR2"
    echo "Success: Directory created."
else
    echo "Directory $TARGET_DIR2 already exists. No action needed."
fi


# 4. Download YAML files into the target directory
echo "Downloading Ansible playbooks to $TARGET_DIR..."

wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/main.yml" -O "$TARGET_DIR/main.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/ansible_bash.yml" -O "$TARGET_DIR/ansible_bash.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/ansible_flatpaks.yml" -O "$TARGET_DIR/ansible_flatpaks.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/ansible_packages.yml" -O "$TARGET_DIR/ansible_packages.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/setup_ai_stack.yml" -O "$TARGET_DIR/setup_ai_stack.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/remove_ai_stack.yml" -O "$TARGET_DIR/remove_ai_stack.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/ansible_dosbox.yml" -O "$TARGET_DIR/ansible_dosbox.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/ansible_gaming_setup.yml" -O "$TARGET_DIR/ansible_gaming_setup.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/ansible_wine.yml" -O "$TARGET_DIR/ansible_wine.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/build_refind_image.yml" -O "$TARGET_DIR/build_refind_image.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/Copy_homebrew_install_shell_file.yml" -O "$TARGET_DIR/Copy_homebrew_install_shell_file.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/system_report.yml" -O "$TARGET_DIR/system_report.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/ansible_bash_keyboard_mouse.yml" -O "$TARGET_DIR/ansible_bash_keyboard_mouse.yml"
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/round2.yml" -O "$TARGET_DIR/round2.yml"
#
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/setup-ansible.sh" -O $HOME/setup-ansible.shell
wget -q "https://raw.githubusercontent.com/Byetvt/batch2/main/brew_msedit_install.sh" -O $TARGET_DIR/brew_msedit_install.sh



echo "Download complete."

ansible-galaxy collection install community.general


# 5. Display helpful usage commands
echo "----------------------------------------------------------------"
echo "Usage Tips:"
echo "Full debug install == ANSIBLE_LOG_PATH=./ansible_debug.log ansible-playbook main.yml -vvv --ask-become-pass"
echo "just run install   == ansible-playbook main.yml --ask-become-pass"
echo "----------------------------------------------------------------"

